====================================================================
                   Super Mario Bros: Game Master                    
                        User Created Levels                         
====================================================================
This download contains user created levels that were uploaded to the
official Super Mario Bros: Game Master Levels Database. Each folder 
in this download is named after the user that uploaded the file. To 
play these files, you need to extract the .lvl files to the Level   
folder, the .wld files to the World folder, and the MIDIs to the    
Music folder. Have fun!                                             
====================================================================
